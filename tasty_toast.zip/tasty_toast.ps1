new-item -Path "c:\users\$env:USERNAME\downloads" -Name "success.dll" -ItemType "file" -value "This is a malicious dll"
rundll32.exe C:\users\$env:USERNAME\downloads\success.dll, fakelibrary

