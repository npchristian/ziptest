new-item -Path "c:\users\public\downloads" -Name "success.dll" -ItemType "file" -value "This is a malicious dll"
rundll32.exe C:\users\public\downloads\success.dll, fakelibrary

